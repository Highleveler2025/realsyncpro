import { useState, useEffect, useRef } from "react";

const TECH_STACK = [
  { name: "GoHighLevel", abbr: "GHL", color: "#4CAF50", desc: "CRM & Automation Hub" },
  { name: "Make.com", abbr: "Make", color: "#6D28D9", desc: "Visual Workflow Builder" },
  { name: "Zapier", abbr: "Zap", color: "#FF4A00", desc: "App Integrations" },
  { name: "Airtable", abbr: "AT", color: "#18BFFF", desc: "Smart Databases" },
  { name: "Google Apps Script", abbr: "GAS", color: "#0F9D58", desc: "Custom Scripting" },
  { name: "N8N", abbr: "N8N", color: "#EA4B71", desc: "Open-Source Automations" },
  { name: "Softr", abbr: "Sftr", color: "#7C3AED", desc: "Client Portals" },
  { name: "Lacy.ai", abbr: "Lacy", color: "#F59E0B", desc: "AI Onboarding" },
  { name: "Google Sheets", abbr: "GS", color: "#34A853", desc: "Data & Dashboards" },
  { name: "Lovable", abbr: "Lov", color: "#EC4899", desc: "Rapid App Builder" },
];

const TESTIMONIALS = [
  {
    name: "Peter M.",
    company: "AWS — American Window Systems",
    role: "Owner",
    text: "We were paying $2,400/mo for MarketSharp and still drowning in spreadsheets. Karen and John rebuilt everything inside GHL — 5 custom dashboards, automated production tracking, real-time commission reports. Saved us $28K in the first year alone.",
    metric: "$28K saved Year 1",
    stars: 5,
  },
  {
    name: "Marcus D.",
    company: "Summit Roofing Co.",
    role: "Operations Manager",
    text: "Before RealSync, we were losing 30% of our leads because nobody followed up fast enough. Now every lead gets a text within 60 seconds, an email sequence, and auto-assigned to a rep. Our close rate jumped from 18% to 34%.",
    metric: "34% close rate",
    stars: 5,
  },
  {
    name: "Jennifer L.",
    company: "ProShield Exteriors",
    role: "Co-Owner",
    text: "I was skeptical about replacing ServiceTitan — we'd been on it for 4 years. But the RealSync team migrated everything in 8 weeks and our team actually uses the new system. That never happened with ServiceTitan.",
    metric: "8-week migration",
    stars: 5,
  },
];

const PAIN_POINTS = [
  {
    icon: "💸",
    title: "Bleeding $2K–5K/mo on software you barely use",
    desc: "MarketSharp, ServiceTitan, Jobber — expensive, clunky, and your team still uses spreadsheets anyway.",
  },
  {
    icon: "📞",
    title: "Leads calling while you're on the roof",
    desc: "Every missed call is a $5,000–$15,000 job walking to your competitor. No automation = no follow-up = no sale.",
  },
  {
    icon: "🔥",
    title: "Your \"system\" is sticky notes and memory",
    desc: "Jobs slip through cracks. Invoices go unsent. Customer callbacks get forgotten. You know it's costing you.",
  },
  {
    icon: "😤",
    title: "You hired a VA — and now you manage the VA",
    desc: "More people ≠ more efficiency. You need systems that run without babysitting.",
  },
];

function AnimatedCounter({ end, duration = 2000, prefix = "", suffix = "" }) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setStarted(true); },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    let start = 0;
    const step = end / (duration / 16);
    const timer = setInterval(() => {
      start += step;
      if (start >= end) { setCount(end); clearInterval(timer); }
      else setCount(Math.floor(start));
    }, 16);
    return () => clearInterval(timer);
  }, [started, end, duration]);

  return <span ref={ref}>{prefix}{count.toLocaleString()}{suffix}</span>;
}

function Calculator() {
  const [leads, setLeads] = useState(20);
  const [missed, setMissed] = useState(40);
  const [jobValue, setJobValue] = useState(8000);

  const missedLeads = Math.round(leads * (missed / 100));
  const closeRate = 0.25;
  const lostJobs = Math.round(missedLeads * closeRate);
  const lostRevenue = lostJobs * jobValue;
  const yearlyLoss = lostRevenue * 12;

  return (
    <div style={styles.calcContainer}>
      <div style={styles.calcGrid}>
        <div style={styles.calcInputSide}>
          <h3 style={styles.calcInputTitle}>Your Numbers</h3>

          <div style={styles.sliderGroup}>
            <div style={styles.sliderLabel}>
              <span style={styles.sliderLabelText}>Leads per month</span>
              <span style={styles.sliderValue}>{leads}</span>
            </div>
            <input type="range" min="5" max="100" value={leads}
              onChange={(e) => setLeads(Number(e.target.value))}
              style={styles.slider}
            />
          </div>

          <div style={styles.sliderGroup}>
            <div style={styles.sliderLabel}>
              <span style={styles.sliderLabelText}>% Missed / Slow follow-up</span>
              <span style={styles.sliderValue}>{missed}%</span>
            </div>
            <input type="range" min="10" max="80" value={missed}
              onChange={(e) => setMissed(Number(e.target.value))}
              style={styles.slider}
            />
          </div>

          <div style={styles.sliderGroup}>
            <div style={styles.sliderLabel}>
              <span style={styles.sliderLabelText}>Avg job value ($)</span>
              <span style={styles.sliderValue}>${jobValue.toLocaleString()}</span>
            </div>
            <input type="range" min="1000" max="30000" step="500" value={jobValue}
              onChange={(e) => setJobValue(Number(e.target.value))}
              style={styles.slider}
            />
          </div>

          <p style={styles.calcNote}>
            * Based on a 25% close rate on followed-up leads — industry average for home services.
          </p>
        </div>

        <div style={styles.calcResultSide}>
          <div style={styles.resultCard}>
            <span style={styles.resultLabel}>Missed leads / month</span>
            <span style={styles.resultNumber}>{missedLeads}</span>
          </div>
          <div style={styles.resultCard}>
            <span style={styles.resultLabel}>Lost jobs / month</span>
            <span style={styles.resultNumber}>{lostJobs}</span>
          </div>
          <div style={{ ...styles.resultCard, ...styles.resultCardBig }}>
            <span style={styles.resultLabel}>Revenue you're losing</span>
            <span style={styles.resultBigNumber}>${lostRevenue.toLocaleString()}<span style={styles.resultPer}>/mo</span></span>
            <span style={styles.resultYearly}>${yearlyLoss.toLocaleString()} / year</span>
          </div>
          <div style={styles.resultCTA}>
            That's a crew's salary. Walking out the door.
          </div>
        </div>
      </div>
    </div>
  );
}

export default function RealSyncPro() {
  const [scrollY, setScrollY] = useState(0);
  const [hoveredTech, setHoveredTech] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div style={styles.page}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Sora:wght@300;400;600;700;800&display=swap');

        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body { overflow-x: hidden; }

        input[type="range"] {
          -webkit-appearance: none;
          appearance: none;
          width: 100%;
          height: 6px;
          border-radius: 3px;
          background: linear-gradient(90deg, #1a1a2e, #2a2a4a);
          outline: none;
          cursor: pointer;
        }
        input[type="range"]::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: #FF3E1D;
          border: 3px solid #fff;
          box-shadow: 0 0 12px rgba(255,62,29,0.5);
          cursor: pointer;
          transition: transform 0.2s;
        }
        input[type="range"]::-webkit-slider-thumb:hover {
          transform: scale(1.2);
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-12px); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 1; }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes glitch {
          0% { text-shadow: 2px 0 #FF3E1D, -2px 0 #00F0FF; }
          25% { text-shadow: -2px 0 #FF3E1D, 2px 0 #00F0FF; }
          50% { text-shadow: 2px 2px #FF3E1D, -2px -2px #00F0FF; }
          75% { text-shadow: -1px 2px #FF3E1D, 1px -2px #00F0FF; }
          100% { text-shadow: 2px 0 #FF3E1D, -2px 0 #00F0FF; }
        }
        @keyframes gridMove {
          0% { background-position: 0 0; }
          100% { background-position: 40px 40px; }
        }
        @keyframes borderGlow {
          0%, 100% { border-color: rgba(255,62,29,0.3); }
          50% { border-color: rgba(255,62,29,0.8); }
        }
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }

        .hero-grid-bg {
          position: absolute;
          inset: 0;
          background-image:
            linear-gradient(rgba(255,62,29,0.06) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,62,29,0.06) 1px, transparent 1px);
          background-size: 40px 40px;
          animation: gridMove 8s linear infinite;
        }

        .pain-card:hover {
          transform: translateY(-6px) scale(1.02);
          border-color: #FF3E1D !important;
          box-shadow: 0 20px 60px rgba(255,62,29,0.15), 0 0 0 1px rgba(255,62,29,0.3);
        }

        .tech-pill:hover {
          transform: translateY(-4px) scale(1.05);
        }

        .testimonial-card:hover {
          transform: translateY(-4px);
          border-color: #FF3E1D !important;
        }

        .cta-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 40px rgba(255,62,29,0.4);
        }

        .nav-link:hover {
          color: #FF3E1D !important;
        }

        .star { display: inline-block; color: #FF3E1D; }
      `}</style>

      {/* NAV */}
      <nav style={{
        ...styles.nav,
        background: scrollY > 50 ? "rgba(8,8,18,0.95)" : "transparent",
        backdropFilter: scrollY > 50 ? "blur(20px)" : "none",
        borderBottom: scrollY > 50 ? "1px solid rgba(255,62,29,0.15)" : "1px solid transparent",
      }}>
        <div style={styles.navInner}>
          <div style={styles.logo}>
            <span style={styles.logoReal}>REAL</span>
            <span style={styles.logoSync}>SYNC</span>
            <span style={styles.logoPro}>PRO</span>
          </div>
          <div style={styles.navLinks}>
            {["Pain Points", "How It Works", "Calculator", "Testimonials"].map((link) => (
              <a key={link} className="nav-link" href={`#${link.toLowerCase().replace(/ /g, "-")}`}
                style={styles.navLink}>{link}</a>
            ))}
            <a href="#calculator" className="cta-btn" style={styles.navCTA}>Free Audit →</a>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section style={styles.hero}>
        <div className="hero-grid-bg" />

        {/* Floating orbs */}
        <div style={{
          position: "absolute", width: 500, height: 500, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,62,29,0.12) 0%, transparent 70%)",
          top: -100, right: -100, animation: "float 6s ease-in-out infinite",
        }} />
        <div style={{
          position: "absolute", width: 300, height: 300, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(0,240,255,0.08) 0%, transparent 70%)",
          bottom: 100, left: -50, animation: "float 8s ease-in-out infinite 1s",
        }} />

        <div style={styles.heroContent}>
          {/* Eyebrow */}
          <div style={styles.eyebrow}>
            <span style={styles.eyebrowDot} />
            FOR WINDOWS, ROOFING & HOME SERVICE COMPANIES
          </div>

          <h1 style={styles.heroTitle}>
            <span style={styles.heroTitleLine1}>Your leads are</span>
            <span style={{ ...styles.heroTitleLine2, animation: "glitch 3s infinite" }}>
              calling your competitor
            </span>
            <span style={styles.heroTitleLine3}>right now.</span>
          </h1>

          <p style={styles.heroSub}>
            While you're on a job site, your phone rings 3 times and goes to voicemail.
            That's <strong style={{ color: "#FF3E1D" }}>$15,000 in roofing jobs</strong> walking
            away every week. We build systems that answer, follow up, and book — automatically.
          </p>

          <div style={styles.heroCTAs}>
            <a href="#calculator" className="cta-btn" style={styles.primaryCTA}>
              See What You're Losing →
            </a>
            <a href="#how-it-works" style={styles.secondaryCTA}>
              How It Works
            </a>
          </div>

          {/* Social proof bar */}
          <div style={styles.proofBar}>
            <div style={styles.proofItem}>
              <span style={styles.proofNumber}><AnimatedCounter end={47} suffix="+" /></span>
              <span style={styles.proofLabel}>Systems Built</span>
            </div>
            <div style={styles.proofDivider} />
            <div style={styles.proofItem}>
              <span style={styles.proofNumber}><AnimatedCounter end={2} prefix="$" suffix="M+" /></span>
              <span style={styles.proofLabel}>Revenue Recovered</span>
            </div>
            <div style={styles.proofDivider} />
            <div style={styles.proofItem}>
              <span style={styles.proofNumber}><AnimatedCounter end={60} suffix="s" /></span>
              <span style={styles.proofLabel}>Avg Response Time</span>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={styles.scrollIndicator}>
          <div style={{ width: 2, height: 30, background: "linear-gradient(to bottom, #FF3E1D, transparent)", animation: "pulse 2s infinite" }} />
        </div>
      </section>

      {/* MARQUEE BANNER */}
      <div style={styles.marquee}>
        <div style={{ display: "flex", animation: "marquee 20s linear infinite", whiteSpace: "nowrap" }}>
          {[...Array(2)].map((_, i) => (
            <span key={i} style={styles.marqueeText}>
              STOP LOSING LEADS &nbsp;⚡&nbsp; AUTOMATE FOLLOW-UPS &nbsp;⚡&nbsp; REPLACE EXPENSIVE SOFTWARE &nbsp;⚡&nbsp; BOOK MORE JOBS &nbsp;⚡&nbsp; STOP LOSING LEADS &nbsp;⚡&nbsp; AUTOMATE FOLLOW-UPS &nbsp;⚡&nbsp; REPLACE EXPENSIVE SOFTWARE &nbsp;⚡&nbsp; BOOK MORE JOBS &nbsp;⚡&nbsp;
            </span>
          ))}
        </div>
      </div>

      {/* PAIN POINTS */}
      <section id="pain-points" style={styles.section}>
        <div style={styles.sectionInner}>
          <div style={styles.sectionHeader}>
            <span style={styles.sectionTag}>THE PROBLEM</span>
            <h2 style={styles.sectionTitle}>Sound familiar?</h2>
            <p style={styles.sectionSub}>
              Every service business owner we meet has at least 3 of these. Which ones are costing you?
            </p>
          </div>

          <div style={styles.painGrid}>
            {PAIN_POINTS.map((pain, i) => (
              <div key={i} className="pain-card" style={{
                ...styles.painCard,
                animation: `slideUp 0.6s ease-out ${i * 0.1}s both`,
              }}>
                <span style={styles.painIcon}>{pain.icon}</span>
                <h3 style={styles.painTitle}>{pain.title}</h3>
                <p style={styles.painDesc}>{pain.desc}</p>
                <div style={styles.painNumber}>0{i + 1}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS / TECH STACK */}
      <section id="how-it-works" style={{ ...styles.section, background: "#0a0a1a" }}>
        <div style={styles.sectionInner}>
          <div style={styles.sectionHeader}>
            <span style={styles.sectionTag}>OUR ARSENAL</span>
            <h2 style={styles.sectionTitle}>
              We don't sell software.<br />
              <span style={{ color: "#FF3E1D" }}>We engineer systems.</span>
            </h2>
            <p style={styles.sectionSub}>
              10+ best-in-class tools. One unified system. Zero BS.
              We replace your $3K/month software stack with something that actually works.
            </p>
          </div>

          <div style={styles.techGrid}>
            {TECH_STACK.map((tech, i) => (
              <div key={i} className="tech-pill"
                onMouseEnter={() => setHoveredTech(i)}
                onMouseLeave={() => setHoveredTech(null)}
                style={{
                  ...styles.techPill,
                  borderColor: hoveredTech === i ? tech.color : "rgba(255,255,255,0.08)",
                  boxShadow: hoveredTech === i ? `0 8px 32px ${tech.color}22, 0 0 0 1px ${tech.color}44` : "none",
                  animation: `slideUp 0.5s ease-out ${i * 0.06}s both`,
                }}
              >
                <div style={{ ...styles.techDot, background: tech.color }} />
                <div>
                  <div style={styles.techName}>{tech.name}</div>
                  <div style={styles.techDesc}>{tech.desc}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Process Steps */}
          <div style={styles.processRow}>
            {[
              { step: "01", title: "Audit", desc: "We map every leak in your current workflow — missed leads, manual tasks, redundant tools." },
              { step: "02", title: "Architect", desc: "We design a unified system in GHL with automations, dashboards, and integrations tailored to your business." },
              { step: "03", title: "Build & Launch", desc: "We build it, migrate your data, train your team, and go live — typically in 4–8 weeks." },
              { step: "04", title: "Optimize", desc: "Monthly retainer to maintain, improve, and scale your system as your business grows." },
            ].map((item, i) => (
              <div key={i} style={styles.processCard}>
                <span style={styles.processStep}>{item.step}</span>
                <h4 style={styles.processTitle}>{item.title}</h4>
                <p style={styles.processDesc}>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CALCULATOR */}
      <section id="calculator" style={styles.section}>
        <div style={styles.sectionInner}>
          <div style={styles.sectionHeader}>
            <span style={styles.sectionTag}>THE MATH</span>
            <h2 style={styles.sectionTitle}>
              How much are missed leads<br />
              <span style={{ color: "#FF3E1D" }}>actually costing you?</span>
            </h2>
            <p style={styles.sectionSub}>
              Drag the sliders. See the damage. Then decide if you can afford to keep winging it.
            </p>
          </div>
          <Calculator />
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="testimonials" style={{ ...styles.section, background: "#0a0a1a" }}>
        <div style={styles.sectionInner}>
          <div style={styles.sectionHeader}>
            <span style={styles.sectionTag}>RESULTS</span>
            <h2 style={styles.sectionTitle}>
              Don't take our word for it.
            </h2>
          </div>

          <div style={styles.testimonialGrid}>
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="testimonial-card" style={styles.testimonialCard}>
                <div style={styles.testimonialStars}>
                  {[...Array(t.stars)].map((_, j) => (
                    <span key={j} className="star" style={{ fontSize: 18 }}>★</span>
                  ))}
                </div>
                <p style={styles.testimonialText}>"{t.text}"</p>
                <div style={styles.testimonialMeta}>
                  <div>
                    <div style={styles.testimonialName}>{t.name}</div>
                    <div style={styles.testimonialRole}>{t.role} — {t.company}</div>
                  </div>
                  <div style={styles.testimonialMetric}>{t.metric}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section style={styles.finalCTA}>
        <div style={styles.finalCTAInner}>
          <h2 style={styles.finalTitle}>
            Every day without a system<br />is a day your competitor wins.
          </h2>
          <p style={styles.finalSub}>
            Free 30-minute audit. We'll show you exactly where leads are falling through — and how to fix it.
          </p>
          <a href="#" className="cta-btn" style={styles.finalBtn}>
            Book Your Free Audit →
          </a>
          <p style={styles.finalNote}>
            No contracts. No pressure. Just clarity.
          </p>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={styles.footer}>
        <div style={styles.footerInner}>
          <div style={styles.logo}>
            <span style={styles.logoReal}>REAL</span>
            <span style={styles.logoSync}>SYNC</span>
            <span style={styles.logoPro}>PRO</span>
          </div>
          <p style={styles.footerText}>
            Business Efficiency Strategists — built by Karen & John.
          </p>
          <p style={{ ...styles.footerText, opacity: 0.4, marginTop: 8 }}>
            © 2026 RealSync Pro. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

const styles = {
  page: {
    fontFamily: "'Sora', sans-serif",
    background: "#080812",
    color: "#E8E8F0",
    minHeight: "100vh",
    overflowX: "hidden",
  },

  // NAV
  nav: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    transition: "all 0.3s ease",
    padding: "0 24px",
  },
  navInner: {
    maxWidth: 1200,
    margin: "0 auto",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "16px 0",
  },
  logo: { display: "flex", gap: 0, alignItems: "baseline" },
  logoReal: { fontFamily: "'Space Mono', monospace", fontWeight: 700, fontSize: 20, color: "#fff", letterSpacing: "-0.5px" },
  logoSync: { fontFamily: "'Space Mono', monospace", fontWeight: 700, fontSize: 20, color: "#FF3E1D", letterSpacing: "-0.5px" },
  logoPro: { fontFamily: "'Space Mono', monospace", fontWeight: 400, fontSize: 12, color: "rgba(255,255,255,0.4)", marginLeft: 4, textTransform: "uppercase", letterSpacing: 2 },
  navLinks: { display: "flex", alignItems: "center", gap: 28 },
  navLink: { color: "rgba(255,255,255,0.6)", textDecoration: "none", fontSize: 13, fontWeight: 400, transition: "color 0.2s", letterSpacing: "0.5px" },
  navCTA: {
    background: "#FF3E1D",
    color: "#fff",
    padding: "10px 22px",
    borderRadius: 8,
    fontSize: 13,
    fontWeight: 600,
    textDecoration: "none",
    transition: "all 0.3s ease",
    letterSpacing: "0.3px",
  },

  // HERO
  hero: {
    position: "relative",
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "120px 24px 80px",
    overflow: "hidden",
  },
  heroContent: {
    position: "relative",
    zIndex: 2,
    maxWidth: 900,
    textAlign: "center",
  },
  eyebrow: {
    display: "inline-flex",
    alignItems: "center",
    gap: 10,
    fontFamily: "'Space Mono', monospace",
    fontSize: 11,
    letterSpacing: 3,
    color: "#FF3E1D",
    textTransform: "uppercase",
    marginBottom: 32,
    padding: "8px 20px",
    border: "1px solid rgba(255,62,29,0.25)",
    borderRadius: 100,
  },
  eyebrowDot: {
    width: 6,
    height: 6,
    borderRadius: "50%",
    background: "#FF3E1D",
    animation: "pulse 2s infinite",
  },
  heroTitle: {
    fontSize: "clamp(36px, 6vw, 72px)",
    fontWeight: 800,
    lineHeight: 1.05,
    marginBottom: 28,
    letterSpacing: "-2px",
  },
  heroTitleLine1: { display: "block", color: "rgba(255,255,255,0.5)", fontSize: "0.65em", fontWeight: 400, letterSpacing: 0 },
  heroTitleLine2: { display: "block", color: "#fff" },
  heroTitleLine3: { display: "block", color: "#FF3E1D" },
  heroSub: {
    fontSize: 18,
    lineHeight: 1.7,
    color: "rgba(255,255,255,0.55)",
    maxWidth: 620,
    margin: "0 auto 40px",
  },
  heroCTAs: { display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" },
  primaryCTA: {
    background: "#FF3E1D",
    color: "#fff",
    padding: "16px 36px",
    borderRadius: 10,
    fontSize: 16,
    fontWeight: 700,
    textDecoration: "none",
    transition: "all 0.3s ease",
    letterSpacing: "0.3px",
  },
  secondaryCTA: {
    background: "transparent",
    color: "rgba(255,255,255,0.7)",
    padding: "16px 36px",
    borderRadius: 10,
    fontSize: 16,
    fontWeight: 500,
    textDecoration: "none",
    border: "1px solid rgba(255,255,255,0.15)",
    transition: "all 0.3s ease",
  },
  proofBar: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    gap: 40,
    marginTop: 64,
    padding: "28px 40px",
    background: "rgba(255,255,255,0.03)",
    border: "1px solid rgba(255,255,255,0.06)",
    borderRadius: 16,
    flexWrap: "wrap",
  },
  proofItem: { display: "flex", flexDirection: "column", alignItems: "center", gap: 4 },
  proofNumber: { fontFamily: "'Space Mono', monospace", fontSize: 28, fontWeight: 700, color: "#FF3E1D" },
  proofLabel: { fontSize: 12, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 2 },
  proofDivider: { width: 1, height: 40, background: "rgba(255,255,255,0.08)" },
  scrollIndicator: {
    position: "absolute",
    bottom: 32,
    left: "50%",
    transform: "translateX(-50%)",
  },

  // MARQUEE
  marquee: {
    overflow: "hidden",
    padding: "16px 0",
    background: "#FF3E1D",
  },
  marqueeText: {
    fontFamily: "'Space Mono', monospace",
    fontSize: 13,
    fontWeight: 700,
    color: "#fff",
    letterSpacing: 3,
    textTransform: "uppercase",
    paddingRight: 20,
  },

  // SECTIONS
  section: { padding: "100px 24px" },
  sectionInner: { maxWidth: 1100, margin: "0 auto" },
  sectionHeader: { textAlign: "center", marginBottom: 64 },
  sectionTag: {
    fontFamily: "'Space Mono', monospace",
    fontSize: 11,
    letterSpacing: 4,
    color: "#FF3E1D",
    textTransform: "uppercase",
    display: "block",
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: "clamp(28px, 4vw, 46px)",
    fontWeight: 800,
    lineHeight: 1.15,
    letterSpacing: "-1px",
    color: "#fff",
    marginBottom: 16,
  },
  sectionSub: {
    fontSize: 17,
    color: "rgba(255,255,255,0.45)",
    maxWidth: 560,
    margin: "0 auto",
    lineHeight: 1.7,
  },

  // PAIN POINTS
  painGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
    gap: 20,
  },
  painCard: {
    position: "relative",
    background: "rgba(255,255,255,0.02)",
    border: "1px solid rgba(255,255,255,0.06)",
    borderRadius: 16,
    padding: "36px 28px 28px",
    transition: "all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
    overflow: "hidden",
    cursor: "default",
  },
  painIcon: { fontSize: 36, display: "block", marginBottom: 16 },
  painTitle: { fontSize: 17, fontWeight: 700, color: "#fff", lineHeight: 1.4, marginBottom: 12 },
  painDesc: { fontSize: 14, color: "rgba(255,255,255,0.4)", lineHeight: 1.6 },
  painNumber: {
    position: "absolute",
    top: 16,
    right: 20,
    fontFamily: "'Space Mono', monospace",
    fontSize: 48,
    fontWeight: 700,
    color: "rgba(255,255,255,0.03)",
  },

  // TECH STACK
  techGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
    gap: 12,
    marginBottom: 64,
  },
  techPill: {
    display: "flex",
    alignItems: "center",
    gap: 14,
    padding: "18px 20px",
    background: "rgba(255,255,255,0.02)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 12,
    cursor: "default",
    transition: "all 0.3s ease",
  },
  techDot: { width: 10, height: 10, borderRadius: "50%", flexShrink: 0 },
  techName: { fontSize: 14, fontWeight: 600, color: "#fff" },
  techDesc: { fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 2 },

  // PROCESS
  processRow: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
    gap: 20,
  },
  processCard: {
    padding: "32px 24px",
    background: "rgba(255,62,29,0.04)",
    border: "1px solid rgba(255,62,29,0.1)",
    borderRadius: 14,
  },
  processStep: {
    fontFamily: "'Space Mono', monospace",
    fontSize: 32,
    fontWeight: 700,
    color: "rgba(255,62,29,0.3)",
    display: "block",
    marginBottom: 12,
  },
  processTitle: { fontSize: 18, fontWeight: 700, color: "#fff", marginBottom: 8 },
  processDesc: { fontSize: 13, color: "rgba(255,255,255,0.4)", lineHeight: 1.6 },

  // CALCULATOR
  calcContainer: {
    background: "rgba(255,255,255,0.02)",
    border: "1px solid rgba(255,255,255,0.06)",
    borderRadius: 20,
    padding: "48px 40px",
    animation: "borderGlow 4s infinite",
  },
  calcGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 48,
    alignItems: "start",
  },
  calcInputSide: {},
  calcInputTitle: {
    fontFamily: "'Space Mono', monospace",
    fontSize: 14,
    color: "rgba(255,255,255,0.5)",
    letterSpacing: 2,
    textTransform: "uppercase",
    marginBottom: 32,
  },
  sliderGroup: { marginBottom: 32 },
  sliderLabel: { display: "flex", justifyContent: "space-between", marginBottom: 12 },
  sliderLabelText: { fontSize: 14, color: "rgba(255,255,255,0.6)" },
  sliderValue: { fontFamily: "'Space Mono', monospace", fontSize: 16, fontWeight: 700, color: "#FF3E1D" },
  slider: {},
  calcNote: { fontSize: 11, color: "rgba(255,255,255,0.25)", lineHeight: 1.5, marginTop: 16 },

  calcResultSide: { display: "flex", flexDirection: "column", gap: 16 },
  resultCard: {
    padding: "20px 24px",
    background: "rgba(255,255,255,0.03)",
    borderRadius: 12,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  resultLabel: { fontSize: 13, color: "rgba(255,255,255,0.45)" },
  resultNumber: { fontFamily: "'Space Mono', monospace", fontSize: 24, fontWeight: 700, color: "#fff" },
  resultCardBig: {
    background: "linear-gradient(135deg, rgba(255,62,29,0.12) 0%, rgba(255,62,29,0.04) 100%)",
    border: "1px solid rgba(255,62,29,0.2)",
    flexDirection: "column",
    alignItems: "flex-start",
    padding: "28px",
    gap: 8,
  },
  resultBigNumber: { fontFamily: "'Space Mono', monospace", fontSize: 40, fontWeight: 700, color: "#FF3E1D" },
  resultPer: { fontSize: 18, color: "rgba(255,62,29,0.6)" },
  resultYearly: { fontFamily: "'Space Mono', monospace", fontSize: 16, color: "rgba(255,255,255,0.3)" },
  resultCTA: {
    textAlign: "center",
    padding: "16px",
    fontSize: 15,
    fontWeight: 600,
    color: "rgba(255,255,255,0.7)",
    fontStyle: "italic",
  },

  // TESTIMONIALS
  testimonialGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
    gap: 20,
  },
  testimonialCard: {
    background: "rgba(255,255,255,0.02)",
    border: "1px solid rgba(255,255,255,0.06)",
    borderRadius: 16,
    padding: "32px 28px",
    transition: "all 0.3s ease",
    cursor: "default",
  },
  testimonialStars: { marginBottom: 16 },
  testimonialText: {
    fontSize: 15,
    lineHeight: 1.7,
    color: "rgba(255,255,255,0.65)",
    marginBottom: 24,
    fontStyle: "italic",
  },
  testimonialMeta: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    borderTop: "1px solid rgba(255,255,255,0.06)",
    paddingTop: 16,
  },
  testimonialName: { fontSize: 15, fontWeight: 700, color: "#fff" },
  testimonialRole: { fontSize: 12, color: "rgba(255,255,255,0.35)", marginTop: 2 },
  testimonialMetric: {
    fontFamily: "'Space Mono', monospace",
    fontSize: 13,
    fontWeight: 700,
    color: "#FF3E1D",
    background: "rgba(255,62,29,0.08)",
    padding: "6px 14px",
    borderRadius: 8,
  },

  // FINAL CTA
  finalCTA: {
    padding: "120px 24px",
    textAlign: "center",
    position: "relative",
    overflow: "hidden",
    background: "linear-gradient(180deg, #080812 0%, #1a0a0a 50%, #080812 100%)",
  },
  finalCTAInner: { position: "relative", zIndex: 2, maxWidth: 700, margin: "0 auto" },
  finalTitle: {
    fontSize: "clamp(28px, 4vw, 44px)",
    fontWeight: 800,
    color: "#fff",
    lineHeight: 1.2,
    letterSpacing: "-1px",
    marginBottom: 20,
  },
  finalSub: {
    fontSize: 17,
    color: "rgba(255,255,255,0.45)",
    marginBottom: 36,
    lineHeight: 1.6,
  },
  finalBtn: {
    display: "inline-block",
    background: "#FF3E1D",
    color: "#fff",
    padding: "18px 48px",
    borderRadius: 12,
    fontSize: 17,
    fontWeight: 700,
    textDecoration: "none",
    transition: "all 0.3s ease",
  },
  finalNote: {
    fontSize: 13,
    color: "rgba(255,255,255,0.25)",
    marginTop: 20,
  },

  // FOOTER
  footer: {
    padding: "48px 24px",
    borderTop: "1px solid rgba(255,255,255,0.05)",
  },
  footerInner: {
    maxWidth: 1100,
    margin: "0 auto",
    textAlign: "center",
  },
  footerText: {
    fontSize: 13,
    color: "rgba(255,255,255,0.35)",
    marginTop: 16,
  },
};
